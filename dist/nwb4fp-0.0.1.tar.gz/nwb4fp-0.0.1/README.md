#Recalculating the quality matrix and downsampling the LFP signal

##install dependencies
pip install nwb4fprobe
