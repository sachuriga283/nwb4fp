<h1><span style="font-size:0.5em;">Recalculating the quality matrix and downsampling the LFP signal</span><br/>
<br/>
<br/>
<h1><span style="font-size:0.5em;">Install dependencies and main functions</span><br/>
<br/>
<span style="font-size:0.5em;">pip install nwb4fp</span><br/>
