import os
import pathlib as Path

def current_path():
    
    print("Current working directory before")
    print(os.getcwd())
    print()
